<template>
	<view>
		hotelset
	</view>
</template>

<script>
	export default{
		date(){
			return {}
		}
	}
</script>

<style>
</style>